package com.timeapi.timeapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TimeapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(TimeapiApplication.class, args);
	}

}
