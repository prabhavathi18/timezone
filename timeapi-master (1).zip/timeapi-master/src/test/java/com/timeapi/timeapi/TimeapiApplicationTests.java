package com.timeapi.timeapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TimeapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
